'''
Virgüllü verilen test datasını excel formatına dönüştürmek ve kolonları ayırmak

'''

import pandas as pd

# Excel dosyasının adını ve yolunu belirtin
excel_file_path = "C:/Users/lenovo/OneDrive/Masaüstü/gps_testleri/gps_M5 algoritması - Kopya-kopya/test_konumlari/6713_86790613880173542.xlsx"  # Dosya yolunu düzenleyin

# Excel dosyasını oku ve DataFrame oluştur
df = pd.read_excel(excel_file_path)
# Boşluk içeren satırları sil
df.dropna(inplace=True)

Data=df["DATA"]
#split metodunu kullanabilmek için listeye çevirdik
Data_Rows = Data.values.tolist()
#içi boş listeler oluşturuyorum
telemetryTime=[]
gps=["latitude","longitude","gpsState"]
latitude=[]
longitude=[]
#gps verilerini sildim



batteryPercentage=[]
activatedBraceletList=["a_braceletSerialNumber","a_connectionStatus","a_distanceRssiPercentage",
                       "a_batteryPercentage","a_braceletVersion","a_braceletHardwareVersion"]

a_distanceRssiPercentage=[]



stepCounterNumber=[]

#burada 3-4 çift olanlar var içerik**************************************************
nonTrackingBraceletList=["n_braceletSerialNumber1","n_mode1"]
n_braceletSerialNumber=[]
n_mode=[]

baseStationInfo=["basestationMcc","basestationMnc","basestationLac","basestationCid","basestationBsic","signalQuality"]


basestationLac=[]
basestationCid=[]
basestationBsic=[]
signalQuality=[]





'''
silinenler
"basestationMnc","a_braceletVersion","a_batteryPercentage","a_connectionStatus","a_braceletSerialNumber","gps_gpsState","senderSerialNumber","a_braceletHardwareVersion","isTimeSync","mcuVersion","bleVersion","unitHardwareVersion","basestationMcc"
'''
# #her bir satırı okuyup , den ayırıp row a atadık
# for i in Data_Rows: 
#     row = i.split(",")
#     if len(row)<33:
#         print("+")
#         print(row)
#     else:
#         print("1111111111")
    # print(row[18])
    # break
# sa=Data_Rows[0].split(",")  
# print(Data_Rows[0])
# print("----------------")
# print(sa)

for i in Data_Rows: #her bir satırı okuyup , den ayırıp row a atadık
    row = i.split(",")#row=[{telemöds,lmllx,dnj,...}]
    # #İLK OLARAK EKSİKLİĞİ OLAN ROWLAR ATLANIYOR
    # #EKsik kolonu olan satırlar atlanacak-->burada fazlalığı olanlar girer fakat onlarda aşağıda elenecekler
    if len(row)<33:#EKsik kolonu olan satırlar atlanacak-->burada fazlalığı olanlar girer fakat onlarda aşağıda elenecekler
        continue
    elif ("braceletSerialNumber" in row[18])==0:
        continue
    elif ("braceletVersion" in row[22])==0:
        continue
    elif (" baseStationInfo={basestationMcc=286" in row)==0: #baz istasyonu bilgisi içermeyen satırları atlıyoruz
        continue
    for i in row:
        if "telemetryTime" in i:
            telemetryTime.append(i.split("=")[1])
        
        elif "latitude" in i:   #gps={latitude=40.762455
            latitude.append(i.split("=")[2])
        elif "longitude" in i:
            longitude.append(i.split("=")[1])
        
        elif "batteryPercentage" in i:
            if i==row[13]: #batteryPercentage   iki ifadede var bu yüzden rowun o anki değeri ile de kontrol sağladım
                batteryPercentage.append(i.split("=")[1])
        
        elif "distanceRssiPercentage" in i:
            if i==row[16]:
                 a_distanceRssiPercentage.append(i.split("=")[1]) #aynı neden
        
        elif "stepCounterNumber" in i:
            stepCounterNumber.append(i.split("=")[1])
        
        elif "basestationLac" in i:
            basestationLac.append(i.split("=")[1])
        elif "basestationCid" in i:
            basestationCid.append(i.split("=")[1])
        elif "basestationBsic" in i:
            basestationBsic.append(i.split("=")[1])
        elif "signalQuality" in i: #signalQuality=15}}
            signalQuality.append(i.split("=")[1][:-2]) 
            
#LİSTELERİ DF ALTINDA TOPLAMA
df1 = pd.DataFrame({'telemetryTime': telemetryTime})
df3 = pd.DataFrame({'gps_latitude': latitude})
df4 = pd.DataFrame({'gps_longitude': longitude})
#gps verilerini sildim

df14 = pd.DataFrame({'batteryPercentage': batteryPercentage})
df17 = pd.DataFrame({'a_distanceRssiPercentage': a_distanceRssiPercentage})
df24 = pd.DataFrame({'stepCounterNumber': stepCounterNumber})
#df26 = pd.DataFrame({'n_braceletSerialNumber': n_braceletSerialNumber})
#df27 = pd.DataFrame({'n_mode': n_mode})
df30 = pd.DataFrame({'basestationLac': basestationLac})
df31 = pd.DataFrame({'basestationCid': basestationCid})
df32 = pd.DataFrame({'basestationBsic': basestationBsic})
df33 = pd.DataFrame({'signalQuality': signalQuality})
result_df = pd.concat([df1,   df14, df17,
                      df24,  df30, df31,df32,df33], axis=1)#df26, df27,
gercek_enlem_boylam=pd.concat([df3, df4],axis=1)

# DataFrame'i Excel dosyasına dönüştür
result_df.to_excel("duzenlenen_xlsx_dosyasi.xlsx", index=False, engine='openpyxl')
gercek_enlem_boylam.to_excel("gercek_enlem_boylam.xlsx",index=False,engine='openpyxl')
print("DataFrame başarıyla dönüştürüldü.")

# ###############################################
# #ilk değişimleri buradan başlatabiliriz bu kolonlar tekrar ediyor
# #gps_gpsState--, a_braceletSerialNumber---, a_connectionStatus--, a_batteryPercentage--, a_braceletVersion--, basestationMnc,
# cikarilacaklar=["basestationMnc","a_braceletVersion","a_batteryPercentage","a_connectionStatus","a_braceletSerialNumber","gps_gpsState","senderSerialNumber","a_braceletHardwareVersion","isTimeSync","mcuVersion","bleVersion","unitHardwareVersion","basestationMcc"] 
# # Seçilen sütunları orijinal DataFrame'den çıkarma
# sade_df = result_df.drop(columns=cikarilacaklar)