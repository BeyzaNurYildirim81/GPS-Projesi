'''
temizlediğim verileri modele sokma ve çıktı alma kodu
'''
import tkinter as tk
from tkinter import filedialog
import pandas as pd
from sklearn.preprocessing import StandardScaler
import joblib
import re
import os
os.environ['CUDA_VISIBLE_DEVICES'] = '-1' # GPU kullanımını engelle

import tensorflow as tf
tf.get_logger().setLevel('ERROR') # TensorFlow'un gereksiz uyarılarını kapat

ham_df = None
scaler = None
model = None

def yukle():
    global ham_df,olculu_ham_df, scaler, model,enlem_kolonu,boylam_kolonu,konum_df,tahmin_df
    dosya_yolu = filedialog.askopenfilename(initialdir="/", title="Excel Dosyasını Seç", filetypes=(("Excel Dosyaları", "*.xlsx"), ("Tüm Dosyalar", "*.*")))
    
    try:
        df = pd.read_excel(dosya_yolu)
        # # Eksik veri içeren satırları sil
        # df.dropna(inplace=True)
        
        # # "=" karakterinden önceki kısmı silme işlemi
        # for column in df.columns:
        #     df[column] = df[column].apply(lambda x: re.sub(r'.*=', '', str(x)))
        # print(df.columns)
        
        
        
        
        # # Belirli metinleri içeren kolonları silme
        # metinler = ["basestationMnc=2","braceletVersion=19419","batteryPercentage=50","connectionStatus","braceletSerialNumber","psState","basestationMcc","TELEMETRY","unitHardwareVersion","bleVersion","mcuVersion","braceletHardwareVersion","senderSerialNumber","gps={latitude=", "longitude=", "altitudeMeters", "directionDegree", "speedMetersPerSecond", "gpsTimeEpoch", "satelliteCountNumber", "HDOP", "PDOP", "VDOP","isTimeSync"]
        # indisler = [i for i, col in enumerate(df.columns) if any(metin in col for metin in metinler)]
        # df.drop(df.columns[indisler], axis=1, inplace=True)
        # # # İlk sütunu sil
        # # df = df.drop(df.columns[0], axis=1)
        
        # ham_df = df.copy()  # ham_df'i df'den kopyalayın
        df.columns = ['telemetryTime',
              'batteryPercentage', 
              'a_distanceRssiPercentage',
              'stepCounterNumber', 'basestationLac',
              'basestationCid', 'basestationBsic', 'signalQuality']
        
        # # "signalquality" sütunundaki "}}" karakterlerini sil
        # ham_df['signalQuality'] = ham_df['signalQuality'].str.rstrip('}')
        
        # # Kategorik verileri sayısala dönüştürme
        # from sklearn.preprocessing import LabelEncoder
        # # Kategorik özellikleri seçme
        # cat_cols = ["a_connectionStatus"]
        # # LabelEncoder nesnesi oluşturma ve verileri dönüştürme
        # le = LabelEncoder()
        # for col in cat_cols:
        #   ham_df[col] = le.fit_transform(ham_df[col])
        
        # Öznitelik ölçeklendirme
        scaler = StandardScaler()
        olculu_ham_df = pd.DataFrame(scaler.fit_transform(df), columns=df.columns)
        print(olculu_ham_df.columns)
        # Modeli yükleme
        from tensorflow.keras.models import load_model
        model = load_model("model.h5")  # Model dosyanızın ismini ve yolunu güncelleyin
        
        
        # Tahminleri yap ve yeni bir Excel tablosu olarak kaydet
        tahminler = model.predict(olculu_ham_df)
        tahmin_df = pd.DataFrame(tahminler, columns=['latitude_tahmin', 'longitude_tahmin'])
        tahmin_df.to_excel("10-1-tahminler.xlsx", index=False)
        
    except Exception as e:
        print("Hata:", e)
    
    root.destroy()  # Pencereyi kapat

root = tk.Tk()

yukle_butonu = tk.Button(root, text="Yükle", command=yukle)
yukle_butonu.pack()

root.mainloop()
