#!/usr/bin/env python
# coding: utf-8

# In[443]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import csv
import json
import itertools


# In[466]:


#içi boş listeler oluturuyorum
telemetryTime=[]
senderSerialNumber=[]
gps=["latitude","longitude","altituteMeters","directionDegree","speedMetersPerSecond",
     "gpsState","gpsTimeEpoch","satelliteCountNumber","HDOP","PDOP","VDOP"]
latitude=[]
longitude=[]
altitudeMeters=[]
directionDegree=[]
speedMetersPerSecond=[]
gpsState=[]
gpsTimeEpoch=[]
satelliteCountNumber=[]
HDOP=[]
PDOP=[]
VDOP=[]

batteryPercentage=[]
activatedBraceletList=["a_braceletSerialNumber","a_connectionStatus","a_distanceRssiPercentage",
                       "a_batteryPercentage","a_braceletVersion","a_braceletHardwareVersion"]
a_braceletSerialNumber=[]
a_connectionStatus=[]
a_distanceRssiPercentage=[]
a_batteryPercentage=[]
a_braceletVersion=[]
a_braceletHardwareVersion=[]

isTimeSync=[]
mcuVersion=[]
bleVersion=[]
stepCounterNumber=[]
unitHardwareVersion=[]

#burada 3-4 çift olanlar var içerik**************************************************
nonTrackingBraceletList=["n_braceletSerialNumber1","n_mode1"]
n_braceletSerialNumber=[]
n_mode=[]

baseStationInfo=["basestationMcc","basestationMnc","basestationLac","basestationCid","basestationBsic","signalQuality"]
basestationMcc=[]
basestationMnc=[]
basestationLac=[]
basestationCid=[]
basestationBsic=[]
signalQuality=[]


# In[467]:


with open("V1_Proto--10908483043206642.csv", "r") as dosya1, open("V1_Proto--83341378852976742.csv", "r") as dosya2:
    icerik1 = dosya1.read()
    icerik2 = dosya2.read()

with open("birlestirilen_veri_seti.csv", "w") as yeni_dosya:
    yeni_dosya.write(icerik1 + icerik2)

/*with open('V1_Proto--10908483043206642.csv', 'r') as file:
    # Dosya okuyucuyu oluştur
    reader = csv.reader(file)
    sayi=0
    for row in reader: #eksik kolonu olanı varsa
        print(row[18])
        if ("braceletVersion" in row[18])==0:
            print("braceletVersion eksik")
            sayi+=1
    print(sayi)*/
# In[468]:


with open('birlestirilen_veri_seti.csv', 'r') as file:
    # Dosya okuyucuyu oluştur
    reader = csv.reader(file)
    for row in reader:
        #İLK OLARAK EKSİKLİĞİ OLAN ROWLAR ATLANIYOR
        if ("braceletSerialNumber" in row[14])==0:
            continue
        #elif("mode" in row[26])==0:
         #   continue
        elif ("braceletVersion" in row[18])==0:
            continue
        elif len(row)<33:#EKsik kolonu olan satırlar atlanacak-->burada fazlalığı olanlar girer fakat onlarda aşağıda elenecekler
            continue
        elif (" baseStationInfo={basestationMcc=286" in row)==0: #baz istasyonu bilgisi içermeyen satırları atlıyoruz
            continue

        for i in row:
            if "telemetryTime" in i:
                telemetryTime.append(i.split("=")[1])
            elif "senderSerialNumber" in i:
                senderSerialNumber.append(i.split("=")[1])
            elif "latitude" in i:   #gps={latitude=40.762455
                latitude.append(i.split("=")[2])
            elif "longitude" in i:
                longitude.append(i.split("=")[1])
            elif "altitudeMeters" in i:
                altitudeMeters.append(i.split("=")[1])
            elif "directionDegree" in i:
                directionDegree.append(i.split("=")[1])
            elif "speedMetersPerSecond" in i:
                speedMetersPerSecond.append(i.split("=")[1])
            elif "gpsState" in i:
                gpsState.append(i.split("=")[1])
            elif "gpsTimeEpoch" in i:
                gpsTimeEpoch.append(i.split("=")[1])
            elif "satelliteCountNumber" in i:
                satelliteCountNumber.append(i.split("=")[1])
            elif "HDOP" in i:
                HDOP.append(i.split("=")[1])
            elif "PDOP" in i:
                PDOP.append(i.split("=")[1])
            elif "VDOP" in i:   #VDOP=0.9}
                VDOP.append(i.split("=")[1][:-1])
            elif "batteryPercentage" in i:
                if len(batteryPercentage)>len(a_batteryPercentage):#eğer ilk olanın elemanı fazlaysa gelen eleman ikinciye atanacak
                    a_batteryPercentage.append(i.split("=")[1])
                else:
                    batteryPercentage.append(i.split("=")[1])
            elif "activatedBraceletList" in i:   #activatedBraceletList=[{braceletSerialNumber=119516016230920
                a_braceletSerialNumber.append(i.split("=")[2])
            elif "connectionStatus" in i:
                a_connectionStatus.append(i.split("=")[1])
            elif "distanceRssiPercentage" in i:
                a_distanceRssiPercentage.append(i.split("=")[1])
            elif "braceletVersion" in i:
                a_braceletVersion.append(i.split("=")[1])
            elif "braceletHardwareVersion" in i: #braceletHardwareVersion=14}]
                a_braceletHardwareVersion.append(i.split("=")[1][:-2])
            elif "isTimeSync" in i:
                isTimeSync.append(i.split("=")[1])
            elif "mcuVersion" in i:
                mcuVersion.append(i.split("=")[1])
            elif "bleVersion" in i:
                bleVersion.append(i.split("=")[1])
            elif "stepCounterNumber" in i:
                stepCounterNumber.append(i.split("=")[1])
            elif "unitHardwareVersion" in i:
                unitHardwareVersion.append(i.split("=")[1])
            #elif "nonTrackingBraceletList" in i: #nonTrackingBraceletList=[{braceletSerialNumber=119516016233021
             #   n_braceletSerialNumber.append(i.split("=")[2])
            #elif "mode" in i: #mode=BRACELETMODE_UNRECOGNIZED}]
             #   n_mode.append(i.split("=")[1][:-2])
            elif "baseStationInfo" in i: #baseStationInfo={basestationMcc=286
                basestationMcc.append(i.split("=")[2])
            elif "basestationMnc" in i:
                basestationMnc.append(i.split("=")[1])
            elif "basestationLac" in i:
                basestationLac.append(i.split("=")[1])
            elif "basestationCid" in i:
                basestationCid.append(i.split("=")[1])
            elif "basestationBsic" in i:
                basestationBsic.append(i.split("=")[1])
            elif "signalQuality" in i: #signalQuality=15}}
                signalQuality.append(i.split("=")[1][:-2]) 
            #else:
                #print(row)
             #   print("kaldırılan,dict olarak verilen :eksik olan:"+sayi)
        
    
            #print(i)


# In[474]:


#LİSTELERİ DF ALTINDA TOPLAMA
df1 = pd.DataFrame({'telemetryTime': telemetryTime})
df2 = pd.DataFrame({'senderSerialNumber': senderSerialNumber})
df3 = pd.DataFrame({'gps_latitude': latitude})
df4 = pd.DataFrame({'gps_longitude': longitude})
df5 = pd.DataFrame({'gps_altitudeMeters': altitudeMeters})
df6 = pd.DataFrame({'gps_directionDegree': directionDegree})
df7 = pd.DataFrame({'gps_speedMetersPerSecond': speedMetersPerSecond})
df8 = pd.DataFrame({'gps_gpsState': gpsState})
df9 = pd.DataFrame({'gps_gpsTimeEpoch': gpsTimeEpoch})
df10 = pd.DataFrame({'gps_satelliteCountNumber': satelliteCountNumber})
df11 = pd.DataFrame({'gps_HDOP': HDOP})
df12 = pd.DataFrame({'gps_PDOP': PDOP})
df13 = pd.DataFrame({'gps_VDOP': VDOP})
df14 = pd.DataFrame({'batteryPercentage': batteryPercentage})
df15 = pd.DataFrame({'a_braceletSerialNumber': a_braceletSerialNumber})
df16 = pd.DataFrame({'a_connectionStatus': a_connectionStatus})
df17 = pd.DataFrame({'a_distanceRssiPercentage': a_distanceRssiPercentage})
df18 = pd.DataFrame({'a_batteryPercentage': a_batteryPercentage})
df19 = pd.DataFrame({'a_braceletVersion': a_braceletVersion})
df20 = pd.DataFrame({'a_braceletHardwareVersion': a_braceletHardwareVersion})
df21 = pd.DataFrame({'isTimeSync': isTimeSync})
df22 = pd.DataFrame({'mcuVersion': mcuVersion})
df23 = pd.DataFrame({'bleVersion': bleVersion})
df24 = pd.DataFrame({'stepCounterNumber': stepCounterNumber})
df25 = pd.DataFrame({'unitHardwareVersion': unitHardwareVersion})
#df26 = pd.DataFrame({'n_braceletSerialNumber': n_braceletSerialNumber})
#df27 = pd.DataFrame({'n_mode': n_mode})
df28 = pd.DataFrame({'basestationMcc': basestationMcc})
df29 = pd.DataFrame({'basestationMnc': basestationMnc})
df30 = pd.DataFrame({'basestationLac': basestationLac})
df31 = pd.DataFrame({'basestationCid': basestationCid})
df32 = pd.DataFrame({'basestationBsic': basestationBsic})
df33 = pd.DataFrame({'signalQuality': signalQuality})
result_df = pd.concat([df1, df2, df3, df4, df5, df6, df7, df8, df9, df10, df11, df12, df13, df14, df15, df16, df17, df18,
                      df19,df20, df21, df22, df23, df24, df25,  df28, df29, df30, df31,df32,df33], axis=1)#df26, df27,
print(result_df)


# In[475]:


bos_sutunlar = result_df.columns[result_df.isna().any()].tolist()
print(bos_sutunlar)


# In[471]:


# Boş satırları bulalım
null_rows = result_df[result_df.isnull().any(axis=1)]

# Boş satırların sayısını ve indekslerini yazdıralım
print("Boş satır sayısı: ", len(null_rows))
print("Boş satırların indeksleri: ", null_rows.index.tolist()) 
print(len(result_df))


# In[473]:


#BİRDEN FAZLA TEKRAR EDEN ELEMANLARI BULMAK İÇİN
tekrar_sayisi = {}

for eleman in result_df:
    if eleman in tekrar_sayisi:
        tekrar_sayisi[eleman] += 1
    else:
        tekrar_sayisi[eleman] = 1

print("Birden fazla kez tekrar eden elemanlar: ")
for eleman, sayi in tekrar_sayisi.items():
    if sayi > 1:
        print(f"{eleman} elemanı {sayi} kez tekrar edildi.")


# In[403]:


#index bulmak için
#veri.index.get_loc("telemetryTime")

