import pandas as pd

# İlk Excel dosyasını yükle
df = pd.read_excel("konum_dosyasi.xlsx")

# Enlem ve boylam kolonlarının adlarını belirtin
enlem_kolonu ="Enlem"
boylam_kolonu = "Boylam"

# Enlem ve boylamı istenen formata dönüştür
df[enlem_kolonu] = df[enlem_kolonu].apply(lambda x: str(x).replace(",", "."))
df[boylam_kolonu] = df[boylam_kolonu].apply(lambda x: str(x).replace(",", "."))

# Konum kolonunu oluştur
df["Konum"] = df[enlem_kolonu].astype(str) + "," + df[boylam_kolonu].astype(str)

# Sadece "Konum" kolonunu içeren yeni bir DataFrame oluştur
yeni_df = df[["Konum"]]

# Yeni Excel dosyasına kaydet
yeni_df.to_excel("konum_tahmin_sonuclari.xlsx", index=False)
