import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import csv
import json
import itertools
# Gerekli kütüphanelerin yüklenmesi
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

# İlk CSV dosyasını oku
df1 = pd.read_csv("V1_Proto--83341378852976742.csv", sep=";", header=None)

# İkinci CSV dosyasını oku
df2 = pd.read_csv('V1_Proto--10908483043206642.csv', sep=";", header=None)

# İki DataFrame'i birleştir
df = pd.concat([df1, df2], ignore_index=True)


#içi boş listeler oluşturuyorum

telemetryTime=[]
senderSerialNumber=[]
gps=["latitude","longitude","gpsState"]
latitude=[]
longitude=[]
altitudeMeters=[]
directionDegree=[]
speedMetersPerSecond=[]
gpsTimeEpoch=[]
satelliteCountNumber=[]
HDOP=[]
PDOP=[]
VDOP=[]
gpsState=[]


batteryPercentage=[]
activatedBraceletList=["a_braceletSerialNumber","a_connectionStatus","a_distanceRssiPercentage",
                       "a_batteryPercentage","a_braceletVersion","a_braceletHardwareVersion"]
a_braceletSerialNumber=[]
a_connectionStatus=[]
a_distanceRssiPercentage=[]
a_batteryPercentage=[]
a_braceletVersion=[]
a_braceletHardwareVersion=[]

isTimeSync=[]
mcuVersion=[]
bleVersion=[]
stepCounterNumber=[]
unitHardwareVersion=[]

#burada 3-4 çift olanlar var içerik**************************************************
nonTrackingBraceletList=["n_braceletSerialNumber1","n_mode1"]
n_braceletSerialNumber=[]
n_mode=[]

baseStationInfo=["basestationMcc","basestationMnc","basestationLac","basestationCid","basestationBsic","signalQuality"]
basestationMcc=[]
basestationMnc=[]
basestationLac=[]
basestationCid=[]
basestationBsic=[]
signalQuality=[]


#ifadeleri "," kısmından ayırabilmek için
df = df.applymap(lambda x: str(x).split(",") if pd.notnull(x) else None)

# Tek bir kolonu liste olarak al
liste = df.iloc[:, 0].tolist()

for i in liste: #her bir satırı okuyup , den ayırıp row a atadık

    if len(i)<33:#EKsik kolonu olan satırlar atlanacak-->burada fazlalığı olanlar girer fakat onlarda aşağıda elenecekler
        continue
    elif ("braceletSerialNumber" in i[14])==0:
        continue
    elif ("braceletVersion" in i[18])==0:
        continue
#gps verilerini sildim

    elif (" baseStationInfo={basestationMcc=286" in i)==0: #baz istasyonu bilgisi içermeyen satırları atlıyoruz
        continue
    for j in i:
        if "telemetryTime" in j:
            telemetryTime.append(j.split("=")[1])
        elif "senderSerialNumber" in j:
            senderSerialNumber.append(j.split("=")[1])
        elif "latitude" in j:   #gps={latitude=40.762455
            latitude.append(j.split("=")[2])
        elif "longitude" in j:
            longitude.append(j.split("=")[1])
            
        elif "altitudeMeters" in j: 
            altitudeMeters.append(j.split("=")[1])
        elif "directionDegree" in j: 
            directionDegree.append(j.split("=")[1])
        elif "speedMetersPerSecond" in j: 
            speedMetersPerSecond.append(j.split("=")[1])
        elif "gpsTimeEpoch" in j: 
            gpsTimeEpoch.append(j.split("=")[1])
        elif "satelliteCountNumber" in j: 
            satelliteCountNumber.append(j.split("=")[1])
        elif "HDOP" in j: 
            HDOP.append(j.split("=")[1])
        elif "PDOP" in j: 
            PDOP.append(j.split("=")[1])
        elif "VDOP" in j: 
            VDOP.append(j.split("=")[1][:-1])
        
        
        elif "gpsState" in j:
            gpsState.append(j.split("=")[1])
        #gps verilerini sildim
        elif "batteryPercentage" in j:
            if len(batteryPercentage)>len(a_batteryPercentage):#eğer ilk olanın elemanı fazlaysa gelen eleman ikinciye atanacak
                a_batteryPercentage.append(j.split("=")[1])
            else:
                batteryPercentage.append(j.split("=")[1])
        elif "activatedBraceletList" in j:   #activatedBraceletList=[{braceletSerialNumber=119516016230920
            a_braceletSerialNumber.append(j.split("=")[2])
        elif "connectionStatus" in j:
            a_connectionStatus.append(j.split("=")[1])
        elif "distanceRssiPercentage" in j:
            a_distanceRssiPercentage.append(j.split("=")[1])
        elif "braceletVersion" in j:
            a_braceletVersion.append(j.split("=")[1])
        elif "braceletHardwareVersion" in j: #braceletHardwareVersion=14}]
            a_braceletHardwareVersion.append(j.split("=")[1][:-2])
        elif "isTimeSync" in j:
            isTimeSync.append(j.split("=")[1])
        elif "mcuVersion" in j:
            mcuVersion.append(j.split("=")[1])
        elif "bleVersion" in j:
            bleVersion.append(j.split("=")[1])
        elif "stepCounterNumber" in j:
            stepCounterNumber.append(j.split("=")[1])
        elif "unitHardwareVersion" in j:
            unitHardwareVersion.append(j.split("=")[1])
        #elif "nonTrackingBraceletList" in i: #nonTrackingBraceletList=[{braceletSerialNumber=119516016233021
         #   n_braceletSerialNumber.append(i.split("=")[2])
        #elif "mode" in i: #mode=BRACELETMODE_UNRECOGNIZED}]
         #   n_mode.append(i.split("=")[1][:-2])
        elif "baseStationInfo" in j: #baseStationInfo={basestationMcc=286
            basestationMcc.append(j.split("=")[2])
        elif "basestationMnc" in j:
            basestationMnc.append(j.split("=")[1])
        elif "basestationLac" in j:
            basestationLac.append(j.split("=")[1])
        elif "basestationCid" in j:
            basestationCid.append(j.split("=")[1])
        elif "basestationBsic" in j:
            basestationBsic.append(j.split("=")[1])
        elif "signalQuality" in j: #signalQuality=15}}
            signalQuality.append(j.split("=")[1][:-2]) 
            


#LİSTELERİ DF ALTINDA TOPLAMA
df1 = pd.DataFrame({'telemetryTime': telemetryTime})
df2 = pd.DataFrame({'senderSerialNumber': senderSerialNumber})
df3 = pd.DataFrame({'gps_latitude': latitude})
df4 = pd.DataFrame({'gps_longitude': longitude})
#gps verilerini ekledim
df5 = pd.DataFrame({'altitudeMeters': altitudeMeters})
df6 = pd.DataFrame({'directionDegree': directionDegree})
df7 = pd.DataFrame({'speedMetersPerSecond': speedMetersPerSecond})
df9 = pd.DataFrame({'gpsTimeEpoch': gpsTimeEpoch})
df10 = pd.DataFrame({'satelliteCountNumber': satelliteCountNumber})
df11 = pd.DataFrame({'HDOP': HDOP})
df12 = pd.DataFrame({'PDOP': PDOP})
df13 = pd.DataFrame({'VDOP': VDOP})

df8 = pd.DataFrame({'gps_gpsState': gpsState})

df14 = pd.DataFrame({'batteryPercentage': batteryPercentage})
df15 = pd.DataFrame({'a_braceletSerialNumber': a_braceletSerialNumber})
df16 = pd.DataFrame({'a_connectionStatus': a_connectionStatus})
df17 = pd.DataFrame({'a_distanceRssiPercentage': a_distanceRssiPercentage})
df18 = pd.DataFrame({'a_batteryPercentage': a_batteryPercentage})
df19 = pd.DataFrame({'a_braceletVersion': a_braceletVersion})
df20 = pd.DataFrame({'a_braceletHardwareVersion': a_braceletHardwareVersion})
df21 = pd.DataFrame({'isTimeSync': isTimeSync})
df22 = pd.DataFrame({'mcuVersion': mcuVersion})
df23 = pd.DataFrame({'bleVersion': bleVersion})
df24 = pd.DataFrame({'stepCounterNumber': stepCounterNumber})
df25 = pd.DataFrame({'unitHardwareVersion': unitHardwareVersion})
#df26 = pd.DataFrame({'n_braceletSerialNumber': n_braceletSerialNumber})
#df27 = pd.DataFrame({'n_mode': n_mode})
df28 = pd.DataFrame({'basestationMcc': basestationMcc})
df29 = pd.DataFrame({'basestationMnc': basestationMnc})
df30 = pd.DataFrame({'basestationLac': basestationLac})
df31 = pd.DataFrame({'basestationCid': basestationCid})
df32 = pd.DataFrame({'basestationBsic': basestationBsic})
df33 = pd.DataFrame({'signalQuality': signalQuality})
result_df = pd.concat([df1, df2, df3, df4,df5,df6,df7, df8,df9,df10,df11,df12,df13, df14, df15, df16, df17, df18,
                      df19,df20, df21, df22, df23, df24, df25,  df28, df29, df30, df31,df32,df33], axis=1)#df26, df27,
'''
#sadece valid olan veriler kalacak
filtre = result_df['gps_gpsState'] == "GPS_VALID"
result_df = result_df[filtre]

filtre = result_df['gps_gpsState'] != "GPS_VALID"
gps_valid_olmayan_satirlar = result_df[filtre]
kullanilacak_kolonlar=gps_valid_olmayan_satirlar.columns
kullanilacak_kolonlar
'''
farkli_veriler = result_df['gps_gpsState'].unique()
print(farkli_veriler)


#a_braceletVersion,a_braceletHardwareVersion,isTimeSync,mcuVersion,bleVersion,unitHardwareVersion,basestationMcc
#test verisinde olmadığı için şunları da çıkarıyoruz: 
cikarilacaklar=[ 'senderSerialNumber','altitudeMeters',
                'directionDegree', 'speedMetersPerSecond','satelliteCountNumber',
       'gps_gpsState',  'a_braceletSerialNumber',
       'a_connectionStatus',
       'a_braceletVersion', 'a_braceletHardwareVersion', 'isTimeSync',
       'mcuVersion', 'bleVersion',  'unitHardwareVersion',
       'basestationMcc', 'basestationMnc'] 



# Seçilen sütunları orijinal DataFrame'den çıkarma
sade_df = result_df.drop(columns=cikarilacaklar)

from sklearn.preprocessing import StandardScaler
# 'gps_latitude', 'gps_longitude'sütunlarını çıkararak öznitelik ölçeklendirme yapma
X = sade_df.drop(['gps_latitude', 'gps_longitude'], axis=1)
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# ölçeklendirilmiş verileri yeni bir veri çerçevesine aktarma
df_scaled = pd.DataFrame(X_scaled, columns=X.columns)

# 'gps_latitude', 'gps_longitude' sütunlarını ölçeklendirilmiş halleriyle birlikte yeni bir veri çerçevesine ekleyerek sonuç çıktısını oluşturma
df_final = pd.concat([sade_df[['gps_latitude', 'gps_longitude']], df_scaled], axis=1)

# sonuç veri çerçevesini gör
print(df_final.head())

#float olmalı tüm kolonlar yoksa hata veriyor
df_final['gps_latitude'] = df_final['gps_latitude'].astype(float)
df_final['gps_longitude'] = df_final['gps_longitude'].astype(float)




# Bağımsız değişkenlerin seçilmesi   çıkarılanlar(test verisinde yok):'altitudeMeters','directionDegree', 'speedMetersPerSecond','satelliteCountNumber',
X = df_final[['telemetryTime', 'gpsTimeEpoch',
        'HDOP', 'PDOP', 'VDOP', 'batteryPercentage',
       'a_distanceRssiPercentage', 'a_batteryPercentage', 'stepCounterNumber',
       'basestationLac', 'basestationCid', 'basestationBsic', 'signalQuality']]
# Hedef değişkenlerin seçilmesi
y = df_final[['gps_latitude', 'gps_longitude']]

# Verilerin train ve test olarak ayrılması
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)


# Modelin oluşturulması
input_shape = X_train.shape[1]
output_shape = y_train.shape[1]

model = keras.Sequential([
  layers.Dense(64, activation='relu', input_shape=(input_shape,)),
  layers.Dense(64, activation='relu', input_shape=(input_shape,)),
  layers.Dense(64, activation='relu', input_shape=(input_shape,)),
  layers.Dense(64, activation='relu', input_shape=(input_shape,)),
  layers.Dense(64, activation='relu', input_shape=(input_shape,)),
  layers.Dense(64, activation='relu', input_shape=(input_shape,)),
  layers.Dense(64, activation='relu', input_shape=(input_shape,)),
  layers.Dense(64, activation='relu', input_shape=(input_shape,)),
  layers.Dense(64, activation='relu', input_shape=(input_shape,)),
  layers.Dense(64, activation='relu', input_shape=(input_shape,)),
  layers.Dense(64, activation='relu', input_shape=(input_shape,)),
  layers.Dense(64, activation='relu', input_shape=(input_shape,)),
  layers.Dense(64, activation='relu', input_shape=(input_shape,)),   #Test Kaybı: 0.0007097644847817719
  layers.Dense(64, activation='relu'),
  layers.Dense(output_shape)
])

model.compile(optimizer='adam', loss='mse')
model.fit(X_train, y_train, epochs=100, batch_size=32, verbose=1)

# Modelin değerlendirilmesi
evaluation = model.evaluate(X_test, y_test)
print("Test Kaybı:", evaluation)

#Modeli kaydetmek için
from joblib import dump, load
# Modeli kaydetme
model.save("model2.h5")



