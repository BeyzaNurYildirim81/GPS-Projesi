import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import csv
import json
import itertools
from sklearn.cluster import KMeans


df = pd.read_csv("V1_Proto.csv", sep=";")
#Sadece telemetry verilerini alacağız
df=df[df.iloc[:, 1] == "TELEMETRY"]
Data=df["DATA"]
#split metodunu kullanabilmek için listeye çevirdik
Data_Rows = Data.values.tolist()
#içi boş listeler oluşturuyorum
telemetryTime=[]
senderSerialNumber=[]
gps=["latitude","longitude","gpsState"]
latitude=[]
longitude=[]
#gps verilerini sildim
gpsState=[]


batteryPercentage=[]
activatedBraceletList=["a_braceletSerialNumber","a_connectionStatus","a_distanceRssiPercentage",
                       "a_batteryPercentage","a_braceletVersion","a_braceletHardwareVersion"]
a_braceletSerialNumber=[]
a_connectionStatus=[]
a_distanceRssiPercentage=[]
a_batteryPercentage=[]
a_braceletVersion=[]
a_braceletHardwareVersion=[]

isTimeSync=[]
mcuVersion=[]
bleVersion=[]
stepCounterNumber=[]
unitHardwareVersion=[]

#burada 3-4 çift olanlar var içerik**************************************************
nonTrackingBraceletList=["n_braceletSerialNumber1","n_mode1"]
n_braceletSerialNumber=[]
n_mode=[]

baseStationInfo=["basestationMcc","basestationMnc","basestationLac","basestationCid","basestationBsic","signalQuality"]
basestationMcc=[]
basestationMnc=[]
basestationLac=[]
basestationCid=[]
basestationBsic=[]
signalQuality=[]

#her bir satırı okuyup , den ayırıp row a atadık
for i in Data_Rows: 
    row = i.split(",")
    break
sa=Data_Rows[2484].split(",")  
Data_Rows[2484]

for i in Data_Rows: #her bir satırı okuyup , den ayırıp row a atadık
    row = i.split(",")#row=[{telemöds,lmllx,dnj,...}]
    #İLK OLARAK EKSİKLİĞİ OLAN ROWLAR ATLANIYOR
    #EKsik kolonu olan satırlar atlanacak-->burada fazlalığı olanlar girer fakat onlarda aşağıda elenecekler
    if len(row)<33:#EKsik kolonu olan satırlar atlanacak-->burada fazlalığı olanlar girer fakat onlarda aşağıda elenecekler
        continue
    elif ("braceletSerialNumber" in row[14])==0:
        continue
    elif ("braceletVersion" in row[18])==0:
        continue
    elif (" baseStationInfo={basestationMcc=286" in row)==0: #baz istasyonu bilgisi içermeyen satırları atlıyoruz
        continue
    for i in row:
        if "telemetryTime" in i:
            telemetryTime.append(i.split("=")[1])
        elif "senderSerialNumber" in i:
            senderSerialNumber.append(i.split("=")[1])
        elif "latitude" in i:   #gps={latitude=40.762455
            latitude.append(i.split("=")[2])
        elif "longitude" in i:
            longitude.append(i.split("=")[1])
        
        elif "gpsState" in i:
            gpsState.append(i.split("=")[1])
        elif "batteryPercentage" in i:
            if len(batteryPercentage)>len(a_batteryPercentage):#eğer ilk olanın elemanı fazlaysa gelen eleman ikinciye atanacak
                a_batteryPercentage.append(i.split("=")[1])
            else:
                batteryPercentage.append(i.split("=")[1])
        elif "activatedBraceletList" in i:   #activatedBraceletList=[{braceletSerialNumber=119516016230920
            a_braceletSerialNumber.append(i.split("=")[2])
        elif "connectionStatus" in i:
            a_connectionStatus.append(i.split("=")[1])
        elif "distanceRssiPercentage" in i:
            a_distanceRssiPercentage.append(i.split("=")[1])
        elif "braceletVersion" in i:
            a_braceletVersion.append(i.split("=")[1])
        elif "braceletHardwareVersion" in i: #braceletHardwareVersion=14}]
            a_braceletHardwareVersion.append(i.split("=")[1][:-2])
        elif "isTimeSync" in i:
            isTimeSync.append(i.split("=")[1])
        elif "mcuVersion" in i:
            mcuVersion.append(i.split("=")[1])
        elif "bleVersion" in i:
            bleVersion.append(i.split("=")[1])
        elif "stepCounterNumber" in i:
            stepCounterNumber.append(i.split("=")[1])
        elif "unitHardwareVersion" in i:
            unitHardwareVersion.append(i.split("=")[1])
        elif "baseStationInfo" in i: #baseStationInfo={basestationMcc=286
            basestationMcc.append(i.split("=")[2])
        elif "basestationMnc" in i:
            basestationMnc.append(i.split("=")[1])
        elif "basestationLac" in i:
            basestationLac.append(i.split("=")[1])
        elif "basestationCid" in i:
            basestationCid.append(i.split("=")[1])
        elif "basestationBsic" in i:
            basestationBsic.append(i.split("=")[1])
        elif "signalQuality" in i: #signalQuality=15}}
            signalQuality.append(i.split("=")[1][:-2]) 
            
#LİSTELERİ DF ALTINDA TOPLAMA
df1 = pd.DataFrame({'telemetryTime': telemetryTime})
df2 = pd.DataFrame({'senderSerialNumber': senderSerialNumber})
df3 = pd.DataFrame({'gps_latitude': latitude})
df4 = pd.DataFrame({'gps_longitude': longitude})
#gps verilerini sildim
df8 = pd.DataFrame({'gps_gpsState': gpsState})

df14 = pd.DataFrame({'batteryPercentage': batteryPercentage})
df15 = pd.DataFrame({'a_braceletSerialNumber': a_braceletSerialNumber})
df16 = pd.DataFrame({'a_connectionStatus': a_connectionStatus})
df17 = pd.DataFrame({'a_distanceRssiPercentage': a_distanceRssiPercentage})
df18 = pd.DataFrame({'a_batteryPercentage': a_batteryPercentage})
df19 = pd.DataFrame({'a_braceletVersion': a_braceletVersion})
df20 = pd.DataFrame({'a_braceletHardwareVersion': a_braceletHardwareVersion})
df21 = pd.DataFrame({'isTimeSync': isTimeSync})
df22 = pd.DataFrame({'mcuVersion': mcuVersion})
df23 = pd.DataFrame({'bleVersion': bleVersion})
df24 = pd.DataFrame({'stepCounterNumber': stepCounterNumber})
df25 = pd.DataFrame({'unitHardwareVersion': unitHardwareVersion})
#df26 = pd.DataFrame({'n_braceletSerialNumber': n_braceletSerialNumber})
#df27 = pd.DataFrame({'n_mode': n_mode})
df28 = pd.DataFrame({'basestationMcc': basestationMcc})
df29 = pd.DataFrame({'basestationMnc': basestationMnc})
df30 = pd.DataFrame({'basestationLac': basestationLac})
df31 = pd.DataFrame({'basestationCid': basestationCid})
df32 = pd.DataFrame({'basestationBsic': basestationBsic})
df33 = pd.DataFrame({'signalQuality': signalQuality})
result_df = pd.concat([df1, df2, df3, df4, df8, df14, df15, df16, df17, df18,
                      df19,df20, df21, df22, df23, df24, df25,  df28, df29, df30, df31,df32,df33], axis=1)#df26, df27,

###############################################
#ilk değişimleri buradan başlatabiliriz bu kolonlar tekrar ediyor
#gps_gpsState--, a_braceletSerialNumber---, a_connectionStatus--, a_batteryPercentage--, a_braceletVersion--, basestationMnc,
cikarilacaklar=["basestationMnc","a_braceletVersion","a_batteryPercentage","a_connectionStatus","a_braceletSerialNumber","gps_gpsState","senderSerialNumber","a_braceletHardwareVersion","isTimeSync","mcuVersion","bleVersion","unitHardwareVersion","basestationMcc"] 
# Seçilen sütunları orijinal DataFrame'den çıkarma
sade_df = result_df.drop(columns=cikarilacaklar)

# #Verileri sayıya dönüştürme
# from sklearn.preprocessing import LabelEncoder
# # Kategorik özellikleri seçme
# cat_cols = ["a_connectionStatus"]
# # LabelEncoder nesnesi oluşturma ve verileri dönüştürme
# le = LabelEncoder()
# for col in cat_cols:
#     sade_df[col] = le.fit_transform(sade_df[col])

#Öznitelik ölçeklendirme(sıkıştırma işlemi)
from sklearn.preprocessing import StandardScaler
# 'gps_latitude', 'gps_longitude'sütunlarını çıkararak öznitelik ölçeklendirme yapma
X = sade_df.drop(['gps_latitude', 'gps_longitude'], axis=1)
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# ölçeklendirilmiş verileri yeni bir veri çerçevesine aktarma
df_scaled = pd.DataFrame(X_scaled, columns=X.columns)

# 'gps_latitude', 'gps_longitude' sütunlarını ölçeklendirilmiş halleriyle birlikte yeni bir veri çerçevesine ekleyerek sonuç çıktısını oluşturma
df_final = pd.concat([sade_df[['gps_latitude', 'gps_longitude']], df_scaled], axis=1)


#Float olmalı tüm kolonlar yoksa hata veriyor
df_final['gps_latitude'] = df_final['gps_latitude'].astype(float)
df_final['gps_longitude'] = df_final['gps_longitude'].astype(float)
print(df_final.dtypes)

# Gerekli kütüphanelerin yüklenmesi
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout


# Bağımsız değişkenlerin seçilmesi
X = df_final[['telemetryTime', 
       'batteryPercentage',  'a_distanceRssiPercentage', 
        'stepCounterNumber', 
       'basestationLac', 'basestationCid', 'basestationBsic', 'signalQuality']]

# Hedef değişkenlerin seçilmesi
y = df_final[['gps_latitude', 'gps_longitude']]

# Verilerin train ve test olarak ayrılması
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
# Modelin oluşturulması
input_shape = X_train.shape[1]
output_shape = y_train.shape[1]

model = keras.Sequential([
  layers.Dense(64, activation='relu', input_shape=(input_shape,)),
  layers.Dense(64, activation='relu', input_shape=(input_shape,)),
  layers.Dense(64, activation='relu', input_shape=(input_shape,)),
  layers.Dense(64, activation='relu'),
  layers.Dense(output_shape)
])
model.compile(optimizer='adam', loss='mse')
history=model.fit(X_train, y_train, epochs=100, batch_size=32, verbose=1)

# Eğitim kaybının ve doğruluğunun grafiğinin çizilmesi (opsiyonel)
import matplotlib.pyplot as plt

loss = history.history['loss']
epochs = range(1, len(loss) + 1)

plt.plot(epochs, loss, 'b', label='Eğitim Kaybı')
plt.title('Eğitim Kaybı')
plt.xlabel('Epoklar')
plt.ylabel('Kayıp')
plt.legend()
plt.show()

# Modelin değerlendirilmesi
evaluation = model.evaluate(X_test, y_test)
print("Test Kaybı:", evaluation)

#Modeli kaydetmek için
from joblib import dump, load
# Modeli kaydetme
model.save("model.h5")


